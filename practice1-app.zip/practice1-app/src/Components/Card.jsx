import React from 'react'

function Card({image, title, subtitle}) {
  return (
    <div>
        <div className='bg-slate-400 w-[300px] h-[245px] p-4 flex flex-col drop-shadow-xl rounded-md'>

            <img src={image} alt="image" className='rounded-md w-full h-[150px]' />
            <h1 className='text-2xl font-bold pt-2'>{title}</h1>
            <p className='text-lg'>{subtitle}</p>
        </div>
    </div>
  )
}

export default Card