// import React from 'react';
// import { createBrowserRouter, RouterProvider} from 'react-router-dom';
// import Card from './Components/Card';

// function App() {

//   const router = createBrowserRouter([
//     {
//       path: '/',
//       element: <div className='text-red-500'>
//         <Card/>
//         Home
//       </div>,
//     },
//     {
//       path: '/about',
//       element: <div className='text-blue-500'>
//         <Card/>
//         About
//       </div>,
//     },
//     {
//       path: 'Contact us',
//       element: <div className='text-purple-500'>
//         <Card/>
//         contact-us
//       </div>
//     }
//   ]);


//   return (
//     <div>
//       <RouterProvider router = {router} />
//     </div>
//   );
// }

// export default App










import React from 'react'
import Card from './Components/Card'
import image_1 from './image/hill.jpeg'
import image_2 from './image/lake.jpeg'
import image_3 from './image/nature.jpeg'

function App() {
  return (
    <div className='w-full h-screen flex flex-wrap gap-10 justify-center bg-slate-200 pt-10'>
      <Card image={image_1} title={"1st picture"} subtitle={"amazing"}/>
      <Card image={image_2} title={"2nd picture"} subtitle={"amazing"}/>
      <Card image={image_3} title={"3rd picture"} subtitle={"amazing"}/>
    </div>
  )
}

export default App